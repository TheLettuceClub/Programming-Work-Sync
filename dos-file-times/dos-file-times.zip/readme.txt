fsmod-w10.exe: compiled for modern windows via gpp, unknown compatibility with earlier NT
fsmodw9x.exe: compiled for windows 9x via djgpp

compilation instructions:
make sure you have a version of gcc/gpp newer than 2020, as this requires C++17 support

windows 9x (95, 98, ME):
    download and install DJGPP from its website. IMPORTANT: make sure to get the latest version of GCC and GPP, currently G**122b.zip
    type "gxx fsmod.cpp -o fsmodw9x.exe" from the directory containing the file
    run the program

other OSes:
    compile as you see fit with your favorite compiler.
    seems to not want to compile in DOS due to lack of Long File Names, so keep that in mind


Usage:
The program recursively scans every file and sub-directory from the folder from which it's run. Printing names and times as it goes.
When it can't recurse any more, it prints the name and modified time of the most recent file its found.

Pass the -m operator on the command line to disable output for every file. This will speed the search up significantly.

Seems to require some form of DPMI to run. Windows provides this, but if running in DOS, DJGPP's CWSDPMI should be installed

The win9x executable is unfortunately 10mb, and about 2mb compressed. If anyone knows how it could potentially be fit on to a floppy, please tell me.
